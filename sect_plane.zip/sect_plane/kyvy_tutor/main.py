import kivy
from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.gridlayout import GridLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button

class MyGridLayout(GridLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.cols = 2

        but = Button(
            text="World",
            size_hint_x = None,
            width = 100
        )

        self.add_widget(Label(text="Hello"))
        self.add_widget(but)

class MyApp(App):
    def build(self):
        return MyGridLayout()

if __name__ == "__main__":
    app = MyApp()
    app.run()