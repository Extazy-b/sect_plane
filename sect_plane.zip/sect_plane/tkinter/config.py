border = 0.1

canvas_y = 0.075

margin = border * 2

menu_x = 0.2
menu_y = 0.15
menu_weidht = 0
canvas_height = 0.70