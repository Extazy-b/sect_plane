from tkinter import Button, Canvas
from config import *

class Graphick(Canvas):
    def __init__(self, master, height):
        super().__init__(master, bg='white', border=None)

        self.x = height * canvas_y
        self.y = height * canvas_y
        self.height = height * (1 - 3 * canvas_y)
        self.width = height - (3 * height * canvas_y)
        self.points = []
        self.draw()
        #self.buttons()
        self.bind('<Button-3>', self.add_points)
                                            
        print(self.x, self.y, self.height, self.width)
      
    def draw(self):
        self.field = self.create_rectangle(self.x, self.y,
                                           self.width - self.x,
                                           self.height - self.y)

        if self.points:
            self.create_polygon(*self.points, fill='orange', outline='black')

        self.pack()
        self.place(x=self.x, y=self.y, width=self.width, height=self.height)
    
    def add_points(self, event):
        print('start')
        self.flag = True
        self.bind('<Button-1>', self.new_point)
        return
    
    def new_point(self, event):
        if self.flag:
            self.points.append((event.x, event.y))
            print(self.points)
            self.bind('<Button-3>', self.stop_add_points)
        else:
            return
    
    def stop_add_points(self, event):
        print(self.points)
        self.flag = False
        return 

    def buttons(self):
        self.right = Button(bg='red')
        self.right.place(x=self.width * 0.9 + self.x,
                         y=self.height * 0.9 + self.y, 
                         width=self.width * 0.08,
                         height=self.height * 0.08)

        self.left = Button(bg='red')
        self.left.place(x=self.width * 0.9 - self.y * 0.5,
                        y=self.height * 0.9 + self.y, 
                        width=self.width * 0.08,
                        height=self.height * 0.08)

        self.right.bind('<ButtonPress-1>', self.push_right)
        self.right.bind('<ButtonRelease-1>', self.push_left)
    
    def push_right(self, event):
        print("Right")
    
    def push_left(self, event):
        print("Left")
    
    def rotation_start(self, event):
        self.start_x = event.x
        self.start_y = event.y
        self.flag = True

        self.bind('<Motion>', self.rotation)
    
    def rotation_stop(self, event):
        #print('stop')
        self.flag = False
        self.start_x = event.x
        self.start_y = event.y
        
    
    
