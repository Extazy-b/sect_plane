from tkinter import Canvas
from config import *

class Menu(Canvas):
    def __init__(self, master, height, width):
        super().__init__(master, bg='blue')
        self.place(x=height * (1 + margin - 2 * canvas_y),
        y=height * canvas_y,
        width=width - height * (1 + margin - canvas_y),
        height=height * (1 - 3 * canvas_y))  