import tkinter as tk

class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.draw()
        self.pack(fill='both')
        #self.create_widgets()

    def interface(self):
        #inter = tk.
        pass

    def draw(self):
        canvas = tk.Canvas(master=window, borderwidth=10, bg='red') #создание холста для отрисовки фигур
        for i in range(0, canvas.winfo_height(), 20):             #отрисовка
            canvas.create_line(i, 0, i, canvas.winfo_width())    #сетки           
        for i in range(0, 500, 20):             #для
            canvas.create_line(0, i, 500, i)    #проснтранства      
        canvas.pack(fill='both', expand=1) #рендеринг холста

    def create_widgets(self):
        self.hi_there = tk.Button(self)
        self.hi_there["text"] = "Hello World\n(click me)"
        self.hi_there["command"] = self.say_hi
        self.hi_there.pack(side="top")

        self.quit = tk.Button(self, text="QUIT", fg="red",
                              command=self.master.destroy)
        self.quit.pack(side="bottom")

    def say_hi(self):
        print("hi there, everyone!")

window = tk.Tk()
window.geometry('500x500+100+200')
app = Application(master=window)
app.mainloop()