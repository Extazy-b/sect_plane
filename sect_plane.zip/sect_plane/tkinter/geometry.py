import tkinter as tk
from tkinter.constants import X
from config import *
from graphick import Graphick
from menu import Menu
window = tk.Tk()

width = window.winfo_screenwidth()
height = window.winfo_screenheight()
print(width, height)

window.geometry(f'{width}x{height}')
window.update_idletasks()

canvas = Graphick(window, window.winfo_height())

menu = Menu(window,window.winfo_height(), window.winfo_width())

window.pack() 