from kivy.app import App
from kivy.uix.gridlayout import GridLayout
from kivy.lang.builder import Builder
from kivy.uix.widget import Widget
 

class Main(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)


class Sect_planeApp(App):
    def build(self): 
        return Main()

Builder.load_file('kivy/Sect_plane.kv')

if __name__ == '__main__':
    app = Sect_planeApp()
    app.run()