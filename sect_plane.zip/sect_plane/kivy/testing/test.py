import kivy
from kivy.app import App
from kivy.uix.button import Button
from kivy.lang.builder import Builder


class MyFirstKivyApp(App):
    def build(self):
        return Button()

Builder.load_file('kivy/testing/MyFirstKivy.kv')

if __name__ == "__main__":
    MyFirstKivyApp().run()
